#!/bin/bash
# removes all java class files
rm -f *.class
echo uninstall finished